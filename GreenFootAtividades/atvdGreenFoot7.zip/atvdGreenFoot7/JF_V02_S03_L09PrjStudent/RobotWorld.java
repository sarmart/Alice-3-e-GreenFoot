import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class RobotWorld extends World
{
    // 8 e 9. propriedades
    private int currentMaxTurnSpeed = 2;
    private int currentLevel = 1;

    public RobotWorld()
    {    
        super(800, 600, 1); 
        prepare();
    }

    private void prepare()
    {
        Robo robo = new Robo();
        addObject(robo, 48, 50);

        // 6. substitui new Bloco() por new Bloco(2)
        addObject(new Bloco(2), 427, 145);

        Casa casa = new Casa();
        addObject(casa, 751, 552);

        // paredes
        addObject(new Parede(), 48, 147);
        addObject(new Parede(), 159, 147);
        addObject(new Parede(), 266, 147);
        addObject(new Parede(), 587, 147);
        addObject(new Parede(), 692, 147);
        addObject(new Parede(), 791, 147);

        // pizzas iniciais
        addObject(new Pizza(), 720, 46);
        addObject(new Pizza(), 433, 38);
        addObject(new Pizza(), 189, 302);
        addObject(new Pizza(), 682, 312);
        addObject(new Pizza(), 417, 537);
    }

    // 10. método setUpLevel()
    public void setUpLevel()
    {
        if (currentLevel == 2)
        {
            currentMaxTurnSpeed++;
            addObject(new Bloco(currentMaxTurnSpeed), 400, 300);
            for (int i = 0; i < 5; i++)
                addObject(new Pizza(), Greenfoot.getRandomNumber(780), Greenfoot.getRandomNumber(580));
        }
        else if (currentLevel == 3)
        {
            currentMaxTurnSpeed++;
            addObject(new Bloco(currentMaxTurnSpeed), 400, 300);
            for (int i = 0; i < 5; i++)
                addObject(new Pizza(), Greenfoot.getRandomNumber(780), Greenfoot.getRandomNumber(580));
        }
        else if (currentLevel == 4)
        {
            // 11. parte livre — exemplo:
            currentMaxTurnSpeed++;
            addObject(new Bloco(currentMaxTurnSpeed), 400, 300);
            for (int i = 0; i < 7; i++)
                addObject(new Pizza(), Greenfoot.getRandomNumber(780), Greenfoot.getRandomNumber(580));
        }
    }

    // 12, 13 e 14
    public void increaseLevel()
    {
        currentLevel++;
        setUpLevel();
    }
}
