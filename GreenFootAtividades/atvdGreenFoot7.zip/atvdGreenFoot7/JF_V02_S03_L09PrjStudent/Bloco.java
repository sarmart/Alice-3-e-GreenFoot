import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Bloco extends Actor
{
    // 2. velocidade de giro
    private int turnSpeed;

    // 3. Construtor com parâmetro
    public Bloco(int maxTurnSpeed)
    {
        // 4. define valor aleatório entre -maxTurnSpeed e +maxTurnSpeed
        turnSpeed = Greenfoot.getRandomNumber(maxTurnSpeed * 2 + 1) - maxTurnSpeed;

        // 5. se for 0, muda para 1
        if (turnSpeed == 0) {
            turnSpeed = 1;
        }
    }

    public void act()
    {
        // 7. usa turnSpeed em vez de valor fixo
        turn(turnSpeed);
    }
}
