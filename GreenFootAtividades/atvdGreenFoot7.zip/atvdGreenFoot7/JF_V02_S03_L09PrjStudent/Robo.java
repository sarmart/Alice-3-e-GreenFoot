import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Robo extends Actor
{
    private GreenfootImage robotimage1;
    private GreenfootImage robotimage2;
    private GreenfootImage gameoverimage;

    private int vidas;
    private int pontuacao;
    private int pizzaEaten;
    private int animationCounter = 0;

    // 16 e 17. temporizador
    private int temporizador;
    private final int MAXTIMER = 1000;

    public Robo()
    {
        robotimage1 = new GreenfootImage("man01.png");
        robotimage2 = new GreenfootImage("man02.png");
        gameoverimage = new GreenfootImage("gameover.png");
        setImage(robotimage1);

        vidas = 3;
        pontuacao = 0;
        pizzaEaten = 0;
        temporizador = MAXTIMER; // 18

        showStatus();
    }

    public void act()
    {
        robotMovement();
        detectWallCollision();
        detectBlockCollision();
        detectHome();
        eatPizza();
        updateTimer(); // 19
    }

    public void animate()
    {
        animationCounter++;
        if (animationCounter < 5) return;
        animationCounter = 0;

        if (getImage() == robotimage1) setImage(robotimage2);
        else setImage(robotimage1);
    }

    public void robotMovement()
    {
        boolean moved = false;
        if (Greenfoot.isKeyDown("left")) { setLocation(getX() - 10, getY()); moved = true; }
        else if (Greenfoot.isKeyDown("right")) { setLocation(getX() + 10, getY()); moved = true; }
        else if (Greenfoot.isKeyDown("up")) { setLocation(getX(), getY() - 10); moved = true; }
        else if (Greenfoot.isKeyDown("down")) { setLocation(getX(), getY() + 10); moved = true; }

        if (moved) animate();
    }

    public void detectWallCollision()
    {
        if (isTouching(Parede.class))
        {
            Greenfoot.playSound("hurt.wav");
            removeLife(); // 24 — sem setLocation
        }
    }

    public void detectBlockCollision()
    {
        if (isTouching(Bloco.class))
        {
            Greenfoot.playSound("hurt.wav");
            removeLife(); // 24 — sem setLocation
        }
    }

    public void detectHome()
    {
        if (isTouching(Casa.class))
        {
            if (getWorld().getObjects(Pizza.class).isEmpty())
            {
                Greenfoot.playSound("yipee.wav");
                pizzaEaten = 0;
                increaseScore();

                // 15. aumenta nível
                RobotWorld myworld = (RobotWorld)getWorld();
                myworld.increaseLevel();

                resetPosition(); // 25
                resetTimer();    // 28
            }
        }
    }

    public void eatPizza()
    {
        if (isTouching(Pizza.class))
        {
            removeTouching(Pizza.class);
            Greenfoot.playSound("eat.wav");
            pizzaEaten++;

            // 29. aumenta tempo em +200
            temporizador += 200;
        }
    }

    public void removeLife()
    {
        vidas--;
        showStatus();
        resetPosition(); // 23
        testEndGame();
    }

    public void testEndGame()
    {
        if (vidas <= 0)
        {
            setImage(gameoverimage);
            Greenfoot.stop();
        }
    }

    public void increaseScore()
    {
        pontuacao++;
        showStatus();
    }

    public void showStatus()
    {
        World mundo = getWorld();
        if (mundo != null)
        {
            mundo.showText("Vidas: " + vidas, 70, 20);
            mundo.showText("Pontuação: " + pontuacao, 70, 40);
        }
    }

    // 19–21: Atualiza cronômetro
    public void updateTimer()
    {
        temporizador--;
        World mundo = getWorld();
        if (mundo != null)
        {
            mundo.showText("Tempo: " + temporizador, 70, 580);
        }

        if (temporizador <= 0)
        {
            removeLife();
            resetTimer(); // 27
        }
    }

    // 22. Reset posição
    public void resetPosition()
    {
        setLocation(48, 50);
    }

    // 26. Reset timer
    public void resetTimer()
    {
        temporizador = MAXTIMER;
    }
}
