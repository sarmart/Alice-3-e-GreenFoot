import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Robo extends Actor
{
    // 2. Campos de imagem
    private GreenfootImage robotimage1;
    private GreenfootImage robotimage2;
    private GreenfootImage gameoverimage;
    
    // 7, 8 e 9. Propriedades de vidas, pontuação e pizzas comidas
    private int vidas;
    private int pontuacao;
    private int pizzaEaten;
    
    // contador para desacelerar a animação
    private int animationCounter = 0;

    // 3. Construtor
    public Robo() {
        robotimage1 = new GreenfootImage("man01.png");
        robotimage2 = new GreenfootImage("man02.png");
        gameoverimage = new GreenfootImage("gameover.png");
        setImage(robotimage1);
        
        vidas = 3;
        pontuacao = 0;
        pizzaEaten = 0;
        
        showStatus(); // exibe status inicial
    }

    public void act()
    {
        robotMovement();
        detectWallCollision();
        detectBlockCollision();
        detectHome();
        eatPizza();
    }

    // 4. Método animate()
    public void animate()
    {
        // 19 (advanced): só troca a cada 5 atos
        animationCounter++;
        if (animationCounter < 5) {
            return;
        }
        animationCounter = 0;

        // 5. Alterna imagem
        if (getImage() == robotimage1) {
            setImage(robotimage2);
        } else {
            setImage(robotimage1);
        }
    }

    // 6. Adicionar animação ao movimento
    public void robotMovement()
    {
        boolean moved = false;
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 10, getY());
            moved = true;
        } else if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 10, getY());
            moved = true;
        } else if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 10);
            moved = true;
        } else if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 10);
            moved = true;
        }

        if (moved) {
            animate();
        }
    }

    public void detectWallCollision()
    {
        if (isTouching(Parede.class))
        {
            Greenfoot.playSound("hurt.wav");
            setLocation(48, 50);
            removeLife(); // 13. remove vida
        }
    }

    public void detectBlockCollision()
    {
        if (isTouching(Bloco.class))
        {
            Greenfoot.playSound("hurt.wav");
            setLocation(48, 50);
            removeLife(); // 13. remove vida
        }
    }

    public void detectHome()
    {
        if (isTouching(Casa.class))
        {
            // 11. só entra se todas as pizzas foram comidas
            if (getWorld().getObjects(Pizza.class).isEmpty())
            {
                Greenfoot.playSound("yipee.wav");
                setLocation(48, 50);
                pizzaEaten = 0; // reseta o contador
                increaseScore(); // 17. aumenta pontuação
            }
        }
    }

    public void eatPizza()
    {
        if (isTouching(Pizza.class))
        {
            removeTouching(Pizza.class);
            Greenfoot.playSound("eat.wav");
            pizzaEaten++; // 10. incrementa pizzas comidas
        }
    }

    // 12. Método removeLife()
    public void removeLife()
    {
        vidas--;
        showStatus(); // 19. atualiza painel
        testEndGame(); // 14. verifica fim de jogo
    }

    // 14 + 15 + 16. Testa fim de jogo
    public void testEndGame()
    {
        if (vidas <= 0)
        {
            setImage(gameoverimage);
            Greenfoot.stop();
        }
    }

    // 17. Aumenta pontuação
    public void increaseScore()
    {
        pontuacao++;
        showStatus(); // 19. atualiza painel
    }

    // 18. Exibe status no mundo
    public void showStatus()
    {
        World mundo = getWorld();
        if (mundo != null)
        {
            mundo.showText("Vidas: " + vidas, 70, 20);
            mundo.showText("Pontuação: " + pontuacao, 70, 40);
        }
    }
}
