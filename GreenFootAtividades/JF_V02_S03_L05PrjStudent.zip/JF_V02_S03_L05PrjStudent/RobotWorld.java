import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @Laura
 
 * @version (a version number or a date)
 */
public class RobotWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public RobotWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Robo robo = new Robo();
        addObject(robo,48,50);
        
        Bloco bloco = new Bloco();
        addObject(bloco,427,145);
        
        Casa casa = new Casa();
        addObject(casa, 751,552);

        Parede parede = new Parede();
        addObject(new Parede(), 48, 147);
        addObject(new Parede(), 52, 147);
        addObject(new Parede(), 159, 147);
        addObject(new Parede(), 266, 147);
        addObject(new Parede(), 587, 147);
        addObject(new Parede(), 692, 147);
        addObject(new Parede(), 791, 147);
        
        addObject(new Pizza(), 720,46);
        addObject(new Pizza(), 433,38);
        addObject(new Pizza(), 189,302);
        addObject(new Pizza(), 682,312);
        addObject(new Pizza(), 417,537);

    
    }
}
