import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Robo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Robo extends Actor
{
    /**
     * Act - do whatever the Robo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        robotMovement();
        detectWallCollision();
        detectBlockCollision();
        detectHome();
        eatPizza();
    }
    public void robotMovement()
    {
        // O código do movimento do robô será adicionado depois.
        if (Greenfoot.isKeyDown("left")) {
            setLocation(getX() - 10, getY());
        } else if (Greenfoot.isKeyDown("right")) {
            setLocation(getX() + 10, getY());
        } else if (Greenfoot.isKeyDown("up")) {
            setLocation(getX(), getY() - 10);
        } else if (Greenfoot.isKeyDown("down")) {
            setLocation(getX(), getY() + 10);
        }
    }
     public void detectWallCollision()
    {
        if (isTouching(Parede.class))  // verifica se o robô encostou em uma parede
        {
        Greenfoot.playSound("hurt.wav"); // sonzinho de DOOOR!!
        setLocation(48, 50); // volta o robô para a posição inicial
        }
    }
    public void detectBlockCollision()
    {
        if (isTouching(Bloco.class))  // verifica se o robô encostou em um bloco
        {
        Greenfoot.playSound("hurt.wav"); // dor mta dor
        setLocation(48, 50);      // volta o robô para o início
        }
    }
    public void detectHome()
    {
        if (isTouching(Casa.class)) 
        {
        setLocation(48, 50); 
        Greenfoot.playSound("yipee.wav"); //YAPIIIIIIII
        }
    }
    public void eatPizza()
    {
        if (isTouching(Pizza.class)) 
        {
        removeTouching(Pizza.class);
        Greenfoot.playSound("eat.wav"); //nho nho nho
        }
    }
}
