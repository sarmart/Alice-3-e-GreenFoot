import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Robo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Robo extends Actor
{
    /**
     * Act - do whatever the Robo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        robotMovement();
        detectWallCollision();
        detectBlockCollision();
    }
    public void robotMovement()
    {
        // O código do movimento do robô será adicionado depois.
    }
     public void detectWallCollision()
    {
        if (isTouching(Parede.class))  // verifica se o robô encostou em uma parede
        {
        setLocation(48, 50);       // volta o robô para a posição inicial
        }
    }
    public void detectBlockCollision()
    {
        if (isTouching(Bloco.class))  // verifica se o robô encostou em um bloco
        {
        setLocation(48, 50);      // volta o robô para o início
        }
    }
}
